# DIA Assignment 2

### Command to execute the code
`python3 mosaic.py "data/1"`


 - Uploaded the Panarama outputs in the [Google Drive.](https://drive.google.com/drive/folders/1n77NGvv18en8-pXyE-_hQwZiE1SKf5JP?usp=sharing)
 
 
