Mainfile: main.m

Install matlab ANN wrapper before running the program. Make sure mex compiler in Matlab is working.