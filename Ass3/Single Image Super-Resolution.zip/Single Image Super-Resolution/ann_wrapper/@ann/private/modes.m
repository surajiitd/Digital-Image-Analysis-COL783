function m = modes()
% modes of operation
m.OPEN = 1;
m.CLOSE = 2;
m.KSEARCH = 3;
m.PRISEARCH=4;
m.FRSEARCH=5;
